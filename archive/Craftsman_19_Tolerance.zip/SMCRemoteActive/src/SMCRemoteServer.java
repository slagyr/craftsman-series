
import java.io.IOException;

public class SMCRemoteServer {
  private static final String SMC_CLASSPATH = "C:/SMC/smc.jar";
  private static final String SMC_CLASSNAME = "smc.Smc";

  public static String buildCommandLine(String file) {
    return "java -cp " +
      SMC_CLASSPATH + " " +
      SMC_CLASSNAME +
      " -f " + file;
  }

  public static boolean executeCommand(String command) {
    Runtime rt = Runtime.getRuntime();
    try {
      Process p = rt.exec(command);
      p.waitFor();
      return p.exitValue() == 0;
    } catch (Exception e) {
      return false;
    }
  }
}
