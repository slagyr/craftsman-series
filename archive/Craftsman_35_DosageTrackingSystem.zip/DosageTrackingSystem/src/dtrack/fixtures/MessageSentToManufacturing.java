package dtrack.fixtures;

import dtrack.Utilities;
import dtrack.messages.SuitRegistrationMessage;
import fit.ColumnFixture;

public class MessageSentToManufacturing extends ColumnFixture {
  private SuitRegistrationMessage message;
  public void execute() throws Exception {
    message = (SuitRegistrationMessage)Utilities.manufacturing.getLastMessage();
  }

  public String messageId() {
    return message.id;
  }

  public int messageArgument() {
    return message.argument;
  }

  public String messageSender() {
    return message.sender;
  }
}
