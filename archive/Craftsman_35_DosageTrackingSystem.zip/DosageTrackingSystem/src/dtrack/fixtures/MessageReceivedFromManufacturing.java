package dtrack.fixtures;

import dtrack.messages.SuitRegistrationAccepted;
import dtrack.policy.Registraar;
import fit.ColumnFixture;

public class MessageReceivedFromManufacturing extends ColumnFixture {
  public String messageId;
  public int messageArgument;
  public String messageSender;
  public String messageRecipient;
  public void execute() {
    SuitRegistrationAccepted message =
      new SuitRegistrationAccepted(messageId,
                                   messageArgument,
                                   messageSender,
                                   messageRecipient);
    Registraar.acceptMessageFromManufacturing(message);
  }
}
