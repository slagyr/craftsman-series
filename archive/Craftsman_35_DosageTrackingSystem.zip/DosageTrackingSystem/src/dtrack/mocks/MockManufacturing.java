package dtrack.mocks;

import dtrack.external.Manufacturing;
import dtrack.messages.SuitRegistrationMessage;

public class MockManufacturing extends Manufacturing {
  private Object lastMessage;

  protected void send(SuitRegistrationMessage msg) {
    lastMessage = msg;
  }

  public Object getLastMessage() {
    return lastMessage;
  }
}
