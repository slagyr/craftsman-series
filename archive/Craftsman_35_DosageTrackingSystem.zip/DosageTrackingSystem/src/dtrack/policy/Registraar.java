package dtrack.policy;

import dtrack.Utilities;
import dtrack.dto.Suit;
import dtrack.gateways.*;
import dtrack.messages.SuitRegistrationAccepted;

public class Registraar {
  public static void acceptMessageFromManufacturing(Object message) {
    SuitRegistrationAccepted suitAck = (SuitRegistrationAccepted) message;
    Suit acceptedSuit = new Suit(suitAck.argument, Utilities.getDate());
    SuitGateway.add(acceptedSuit);
  }
}
