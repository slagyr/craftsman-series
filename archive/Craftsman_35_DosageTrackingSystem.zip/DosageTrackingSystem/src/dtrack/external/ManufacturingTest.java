package dtrack.external;

import dtrack.messages.SuitRegistrationMessage;
import dtrack.mocks.MockManufacturing;
import junit.framework.TestCase;

public class ManufacturingTest extends TestCase {
    public void testRegisterSuitSendsMessageToMfg() throws Exception {
    MockManufacturing mfg = new MockManufacturing();
    mfg.registerSuit(7734);
    SuitRegistrationMessage message = (SuitRegistrationMessage) mfg.getLastMessage();
    assertEquals("Suit Registration", message.id);
    assertEquals("Outside Maintenance", message.sender);
    assertEquals(7734, message.argument);
  }
}
