package dtrack.external;

import dtrack.messages.SuitRegistrationMessage;

public abstract class Manufacturing {
  public void registerSuit(int barCode) {
    SuitRegistrationMessage msg = new SuitRegistrationMessage();
    msg.sender = "Outside Maintenance";
    msg.argument = barCode;
    send(msg);
  }

  protected abstract void send(SuitRegistrationMessage msg);
}
