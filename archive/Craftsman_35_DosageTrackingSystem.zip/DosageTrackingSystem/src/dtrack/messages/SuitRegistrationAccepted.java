package dtrack.messages;

public class SuitRegistrationAccepted {
  public final String id;
  public final int argument;
  public final String sender;
  public final String recipient;

  public SuitRegistrationAccepted(String id, int argument, String sender, String recipient) {
    this.id = id;
    this.argument = argument;
    this.sender = sender;
    this.recipient = recipient;
  }
}
