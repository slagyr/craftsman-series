
import com.objectmentor.SocketService.SocketService;
import com.objectmentor.SocketService.SocketServer;

import java.net.Socket;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class SMCRemoteServer {
  private static final String SMC_CLASSPATH = "C:/SMC/smc.jar";
  private static final String SMC_CLASSNAME = "smc.Smc";
  private SocketService service;

  public static void main(String[] args) throws Exception {
    SMCRemoteServer server = new SMCRemoteServer();
  }

  public SMCRemoteServer() throws Exception {
    service = new SocketService(9000, new SocketServer(){
          public void serve(Socket socket) {
            // SMCRemoteClient has connected.
            try {
              ObjectOutputStream os = new ObjectOutputStream(socket.getOutputStream());
              os.writeObject("SMCR");
              ObjectInputStream is = new ObjectInputStream(socket.getInputStream());
              CompileFileTransaction cft = (CompileFileTransaction)is.readObject();
              String filename = cft.getFilename();
              cft.sourceFile.write();
              String command = buildCommandLine(filename);
              executeCommand(command);
              //Figure out the file name.
              String compiledFile = filename.replaceAll("\\.sm", ".java");
              CompilerResultsTransaction crt = new CompilerResultsTransaction(compiledFile);
              os.writeObject(crt);
              socket.close();
            } catch (Exception e) {

            }
          }
        });
  }

  public static String buildCommandLine(String file) {
    return "java -cp " +
      SMC_CLASSPATH + " " +
      SMC_CLASSNAME +
      " -f " + file;
  }

  public static boolean executeCommand(String command) {
    Runtime rt = Runtime.getRuntime();
    try {
      Process p = rt.exec(command);
      p.waitFor();
      return p.exitValue() == 0;
    } catch (Exception e) {
      return false;
    }
  }
}
