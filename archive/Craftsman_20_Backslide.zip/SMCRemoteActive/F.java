//----------------------------------------------
//
// FSM:       F
// Context:   C
// Err Func:  FSMError
// Version:   
// Generated: Friday 11/28/2003 at 14:52:16 CST
//
//----------------------------------------------


//----------------------------------------------
//
// class F
//    This is the Finite State Machine class
//
public class F extends C
{
  private State itsState;
  private static String itsVersion = "";

  // instance variables for each state
  private I itsIState;

  // constructor
  public F()
  {
    itsIState = new I();

    itsState = itsIState;

    // Entry functions for: I
  }

  // accessor functions

  public String getVersion()
  {
    return itsVersion;
  }

  public String getCurrentStateName()
  {
    return itsState.stateName();
  }

  // event functions - forward to the current State

  public void E()
  {
    itsState.e();
  }

  //--------------------------------------------
  //
  // private class State
  //    This is the base State class
  //
  private abstract class State
  {
    public abstract String stateName();

    // default event functions

    public void e()
    {
      FSMError( "E", itsState.stateName());
    }

  }

  //--------------------------------------------
  //
  // class I
  //    handles the I State and its events
  //
  private class I extends State 
  {
    public String stateName() 
      { return "I"; }

    //
    // responds to E event
    //
    public void e() 
    {
      A();

      // change the state
      itsState = itsIState;
    }
  }

}
