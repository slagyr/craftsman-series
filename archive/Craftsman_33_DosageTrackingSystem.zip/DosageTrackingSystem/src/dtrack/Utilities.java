package dtrack;

import dtrack.dto.Suit;
import dtrack.gateways.*;
import dtrack.mocks.MockManufacturing;

import java.util.Date;

public class Utilities {
  public static Date testDate = null;
  public static SuitGateway suitGateway = new InMemorySuitGateway();
  public static MockManufacturing manufacturing = new MockManufacturing();

  public static Date getDate() {
    return testDate != null ? testDate : new Date();
  }

  public static void acceptMessageFromManufacuring(Object message) {}

  public static Suit[] getSuitsInInventory() {
    return new Suit[0];
  }
}
