
import junit.framework.*;

import java.io.*;
import java.net.Socket;

import com.objectmentor.SocketService.SocketServer;
import com.objectmentor.SocketService.SocketService;

class TestSMCRServer implements SocketServer {
  public String filename = "noFileName";
  public long fileLength = -1;
  public boolean fileReceived = false;
  private PrintStream os;
  private ObjectInputStream is;
  public char[] content;
  public String command;

  public void serve(Socket socket) {
    try {
      os = new PrintStream(socket.getOutputStream());
      is = new ObjectInputStream(socket.getInputStream());
      os.println("SMCR Test Server");
      os.flush();
      parse((String)is.readObject());
    } catch (Exception e) {
    }
  }

  private void parse(String cmd) throws Exception {
    if (cmd != null) {
      if (cmd.equals("Sending")) {
        filename = (String)is.readObject();
        fileLength = is.readLong();
        content = (char[]) is.readObject();
        fileReceived = true;
      }
    }
  }
}

public class TestSMCRemoteClient extends TestCase {
    private SMCRemoteClient c;
    private static final int SMCPORT = 9000;
    private TestSMCRServer server;
    private SocketService smc;

    public TestSMCRemoteClient(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        c = new SMCRemoteClient();
        server = new TestSMCRServer();
        smc = new SocketService(SMCPORT, server);
    }

    protected void tearDown() throws Exception {
        c.close();
        smc.close();
    }

    public void testParseCommandLine() throws Exception {
        c.parseCommandLine(new String[]{"filename"});
        assertEquals("filename", c.filename());
    }

    public void testParseInvalidCommandLine() {
        boolean result = c.parseCommandLine(new String[0]);
        assertTrue("result should be false", !result);
    }

    public void testFileDoesNotExist() throws Exception {
        c.setFilename("thisFileDoesNotExist");
        boolean prepared = c.prepareFile();
        assertEquals(false, prepared);
    }

    public void testCountBytesInFile() throws Exception {
        File f = createTestFile("testFile", "some text");
        c.setFilename("testFile");
        boolean prepared = c.prepareFile();
        f.delete();
        assertTrue(prepared);
        assertEquals(9, c.getFileLength());
    }

    private File createTestFile(String name, String content) throws IOException {
        File f = new File(name);
        FileOutputStream stream = new FileOutputStream(f);
        stream.write(content.getBytes());
        stream.close();
        return f;
    }

    public void testConnectToSMCRemoteServer() throws Exception {
        boolean connection = c.connect();
        assertTrue(connection);
    }

  public void testSendFile() throws Exception {
    File f = createTestFile("testSendFile", "I am sending this file.");
    c.setFilename("testSendFile");
    assertTrue(c.connect());
    assertTrue(c.prepareFile());
    assertTrue(c.sendFile());
    Thread.sleep(50);
    assertTrue(server.fileReceived);
    assertEquals("testSendFile", server.filename);
    assertEquals(23, server.fileLength);
    assertEquals("I am sending this file.", new String(server.content));
    f.delete();
  }
}