package dtrack.gateways;

import dtrack.dto.Suit;

public interface SuitGateway {
  public void add(Suit suit);
  int getNumberOfSuits();

  Suit[] getArrayOfSuits();
}
