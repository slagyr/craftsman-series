package dtrack;

import dtrack.dto.Suit;
import dtrack.gateways.*;
import dtrack.mocks.MockManufacturing;
import dtrack.messages.SuitRegistrationAccepted;

import java.util.Date;

public class Utilities {
  public static Date testDate = null;
  public static SuitGateway suitGateway = new InMemorySuitGateway();
  public static MockManufacturing manufacturing = new MockManufacturing();

  public static Date getDate() {
    return testDate != null ? testDate : new Date();
  }

  public static void acceptMessageFromManufacuring(Object message) {
    SuitRegistrationAccepted suitAck = (SuitRegistrationAccepted) message;
    Suit acceptedSuit = new Suit(suitAck.argument, getDate());
    suitGateway.add(acceptedSuit);
  }

  public static Suit[] getSuitsInInventory() {
    return suitGateway.getArrayOfSuits();
  }
}
