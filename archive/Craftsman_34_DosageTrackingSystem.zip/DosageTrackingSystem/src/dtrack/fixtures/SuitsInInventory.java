package dtrack.fixtures;

import dtrack.Utilities;
import dtrack.dto.Suit;
import fit.RowFixture;

public class SuitsInInventory extends RowFixture {
  public Object[] query() throws Exception {
    return Utilities.getSuitsInInventory();
  }

  public Class getTargetClass() {
    return Suit.class;
  }
}
