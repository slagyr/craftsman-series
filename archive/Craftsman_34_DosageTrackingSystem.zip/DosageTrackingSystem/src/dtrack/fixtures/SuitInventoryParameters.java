package dtrack.fixtures;

import dtrack.Utilities;
import fit.ColumnFixture;

public class SuitInventoryParameters extends ColumnFixture {
  public int numberOfSuits() {
    return Utilities.suitGateway.getNumberOfSuits();
  }
}
