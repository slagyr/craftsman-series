
import junit.framework.TestCase;

import java.io.*;

public class FileCarrierTest extends TestCase {
  public void testAFile() throws Exception {
    final String TESTFILE = "testFile.txt";
    final String TESTSTRING = "test";
    createFile(TESTFILE, TESTSTRING);
    FileCarrier fc = new FileCarrier(TESTFILE);
    new File(TESTFILE).delete();
    fc.write();
    assertTrue(new File(TESTFILE).exists());
    String contents = readFile(TESTFILE);
    assertEquals(TESTSTRING, contents);
  }
  private String readFile(final String TESTFILE) throws IOException {
    BufferedReader reader = new BufferedReader(new FileReader(TESTFILE));
    String line = reader.readLine();
    return line;
  }
  private void createFile(final String TESTFILE, final String TESTSTRING) throws IOException {
    PrintWriter writer = new PrintWriter(new FileWriter(TESTFILE));
    writer.println(TESTSTRING);
    writer.close();
  }
}
