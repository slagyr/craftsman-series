package dtrack.policy;

import dtrack.Utilities;
import dtrack.dto.Suit;
import dtrack.gateways.SuitGateway;
import dtrack.messages.SuitRegistrationAcceptanceMessage;

public class Registrar {
  public static void acceptMessageFromManufacturing(Object message) {
    SuitRegistrationAcceptanceMessage suitAck = (SuitRegistrationAcceptanceMessage) message;
    if (suitAck.id.equals("Suit Registration Accepted")) {
      Suit acceptedSuit = new Suit(suitAck.argument, Utilities.getDate());
      SuitGateway.add(acceptedSuit);
    }
  }
}
