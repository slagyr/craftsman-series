
import junit.framework.TestCase;

import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;

public class SMCRemoteServerTest extends TestCase {
  public void testBuildCommandLine() throws Exception {
    assertEquals("java -cp C:/SMC/smc.jar smc.Smc -f myFile.sm",
      SMCRemoteServer.buildCommandLine("myFile.sm"));
  }

  public void testExecuteCommand() throws Exception {
    File sourceFile = new File("simpleSourceFile.sm");
    PrintWriter pw = new PrintWriter(new FileWriter(sourceFile));
    pw.println("Context C");
    pw.println("FSMName F");
    pw.println("Initial I");
    pw.println("{I{E I A}}");
    pw.close();

    String command = SMCRemoteServer.buildCommandLine("simpleSourceFile.sm");
    assertEquals(true, SMCRemoteServer.executeCommand(command));

    File outputFile = new File("F.java");
    assertTrue(outputFile.exists());
    assertTrue(outputFile.delete());
    assertTrue(sourceFile.delete());
  }

  public void testMakeWorkingDirectory() throws Exception {
    File workingDirectory = SMCRemoteServer.makeWorkingDirectory();
    assertTrue(workingDirectory.exists());
    assertTrue(workingDirectory.isDirectory());
    SMCRemoteServer.deleteWorkingDirectory(workingDirectory);
  }

  public void testDeleteWorkingDirectory() throws Exception {
    File workingDirectory = SMCRemoteServer.makeWorkingDirectory();
    File someFile = new File(workingDirectory, "someFile");
    someFile.createNewFile();
    assertTrue(someFile.exists());

    File subdirectory = new File(workingDirectory, "subdirectory");
    subdirectory.mkdir();
    File subFile = new File(subdirectory, "subfile");
    subFile.createNewFile();
    assertTrue(subFile.exists());

    SMCRemoteServer.deleteWorkingDirectory(workingDirectory);
    assertFalse(someFile.exists());
    assertFalse(subFile.exists());
    assertFalse(subdirectory.exists());
    assertFalse(workingDirectory.exists());
  }

  public void testWorkingDirectoriesAreUnique() throws Exception {
    File wd1 = SMCRemoteServer.makeWorkingDirectory();
    File wd2 = SMCRemoteServer.makeWorkingDirectory();
    assertFalse(wd1.getName().equals(wd2.getName()));
    SMCRemoteServer.deleteWorkingDirectory(wd1);
    SMCRemoteServer.deleteWorkingDirectory(wd2);
  }
}
