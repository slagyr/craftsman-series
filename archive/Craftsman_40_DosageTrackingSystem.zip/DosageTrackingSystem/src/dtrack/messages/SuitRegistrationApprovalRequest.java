package dtrack.messages;

public class SuitRegistrationApprovalRequest {
  public String id;
  public int argument;
  public String sender;
  final static String ID = SuitRegistrationApprovalRequest.class.getName();

  public SuitRegistrationApprovalRequest() {
    id = ID;
  }
}
