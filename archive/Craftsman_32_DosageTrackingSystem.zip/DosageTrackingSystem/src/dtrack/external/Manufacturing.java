package dtrack.external;

public interface Manufacturing {
  public void registerSuit(int barCode);
  public Object getLastMessage();
}
