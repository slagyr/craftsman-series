package dtrack;

import dtrack.messages.SuitRegistrationMessage;
import dtrack.dto.Suit;
import dtrack.gateways.*;
import dtrack.external.Manufacturing;
import dtrack.mocks.MockManufacturing;

import java.util.Date;

public class Utilities {
  public static Date testDate = null;
  private static SuitGateway suitGateway = new InMemorySuitGateway();
  private static Manufacturing manufacturing = new MockManufacturing();

  public static Date getDate() {
    return testDate != null ? testDate : new Date();
  }

  public static int getNumberOfSuitsInInventory() {
    return suitGateway.getNumberOfSuits();
  }

  public static void registerSuit(int barCode) {
    manufacturing.registerSuit(barCode);
  }

  public static Object getLastMessageToManufacturing() {
    SuitRegistrationMessage message = (SuitRegistrationMessage) manufacturing.getLastMessage();
    return message;
  }

  public static void acceptMessageFromManufacuring(Object message) {}

  public static Suit[] getSuitsInInventory() {
    return new Suit[0];
  }

  public static void addSuit(Suit suit) {
    suitGateway.add(suit);
  }
}
