package dtrack.mocks;

import dtrack.external.Manufacturing;
import dtrack.messages.SuitRegistrationMessage;

public class MockManufacturing implements Manufacturing {
  private Object lastMessage;

  public void registerSuit(int barCode) {
    SuitRegistrationMessage msg = new SuitRegistrationMessage();
    msg.id = "Suit Registration";
    msg.sender = "Outside Maintenance";
    msg.argument = barCode;
    lastMessage = msg;
  }

  public Object getLastMessage() {
    return lastMessage;
  }
}
