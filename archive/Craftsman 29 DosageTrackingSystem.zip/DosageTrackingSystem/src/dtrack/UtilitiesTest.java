package dtrack;

import junit.framework.TestCase;

import java.util.*;

public class UtilitiesTest extends TestCase {
  public void testDateGetsTodayWhenNoTestDateIsSpecified() throws Exception {
    Utilities.testDate = null;
    assertTrue(DatesAreVeryClose(new Date(), Utilities.getDate()));
  }

  private boolean DatesAreVeryClose(Date date1, Date date2) {
    GregorianCalendar c1 = new GregorianCalendar();
    GregorianCalendar c2 = new GregorianCalendar();
    c1.setGregorianChange(date1);
    c2.setGregorianChange(date2);
    long differenceInMS = c1.getTimeInMillis() - c2.getTimeInMillis();
    return Math.abs(differenceInMS) <= 1;
  }

  public void testThatTestDateOverridesNormalDate() throws Exception {
    Date t0 = new GregorianCalendar(1959, 11, 5).getTime();
    Utilities.testDate = t0;
    assertEquals(t0, Utilities.getDate());
  }
}
