package dtrack.messages;

public class SuitRegistrationAccepted {
  String id;
  int argument;
  String sender;
  String recipient;

  public SuitRegistrationAccepted(String id, int argument, String sender, String recipient) {
    this.id = id;
    this.argument = argument;
    this.sender = sender;
    this.recipient = recipient;
  }
}
