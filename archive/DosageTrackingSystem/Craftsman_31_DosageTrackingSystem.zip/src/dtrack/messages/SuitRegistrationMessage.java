package dtrack.messages;

public class SuitRegistrationMessage {
  public String id;
  public int argument;
  public String sender;
}
