package dtrack.gateways;

import dtrack.dto.Suit;

import java.util.*;

public class InMemorySuitGateway implements SuitGateway {
  private Map suits = new HashMap();
  public void add(Suit suit) {
    suits.put(new Integer(suit.barCode()), suit);
  }

  public int getNumberOfSuits() {
    return suits.size();
  }
}
