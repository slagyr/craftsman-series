package dtrack;

import dtrack.messages.SuitRegistrationMessage;
import dtrack.dto.Suit;
import dtrack.gateways.*;

import java.util.Date;

public class Utilities {
  public static Date testDate = null;
  private static SuitGateway suitGateway = new InMemorySuitGateway();

  public static Date getDate() {
    return testDate != null ? testDate : new Date();
  }

  public static int getNumberOfSuitsInInventory() {
    return suitGateway.getNumberOfSuits();
  }

  public static void registerSuit(int barCode) {
  }

  public static Object getLastMessageToManufacturing() {
    return new SuitRegistrationMessage();
  }

  public static void acceptMessageFromManufacuring(Object message) {}

  public static Suit[] getSuitsInInventory() {
    return new Suit[0];
  }

  public static void addSuit(Suit suit) {
    suitGateway.add(suit);
  }
}
