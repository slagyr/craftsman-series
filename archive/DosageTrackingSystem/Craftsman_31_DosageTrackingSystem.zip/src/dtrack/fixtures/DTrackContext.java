package dtrack.fixtures;

import fit.ColumnFixture;

import java.util.Date;

import dtrack.Utilities;

public class DTrackContext extends ColumnFixture {
  public Date todaysDate;

  public void execute() throws Exception {
    Utilities.testDate = todaysDate;
  }
}
