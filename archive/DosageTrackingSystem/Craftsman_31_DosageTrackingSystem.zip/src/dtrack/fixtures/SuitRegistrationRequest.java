package dtrack.fixtures;

import fit.ColumnFixture;
import dtrack.Utilities;

public class SuitRegistrationRequest extends ColumnFixture {
  public int barCode;
  public void execute() {
    Utilities.registerSuit(barCode);
  }
}
