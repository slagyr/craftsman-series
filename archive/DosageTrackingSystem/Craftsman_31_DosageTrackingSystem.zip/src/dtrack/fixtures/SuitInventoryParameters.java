package dtrack.fixtures;

import fit.ColumnFixture;
import dtrack.Utilities;

public class SuitInventoryParameters extends ColumnFixture {
  public int numberOfSuits() {
    return Utilities.getNumberOfSuitsInInventory();
  }
}
