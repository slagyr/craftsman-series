package dtrack.fixtures;

import fit.RowFixture;
import dtrack.Utilities;
import dtrack.dto.Suit;

public class SuitsInInventory extends RowFixture {
  public Object[] query() throws Exception {
    return Utilities.getSuitsInInventory();
  }

  public Class getTargetClass() {
    return Suit.class;
  }
}
