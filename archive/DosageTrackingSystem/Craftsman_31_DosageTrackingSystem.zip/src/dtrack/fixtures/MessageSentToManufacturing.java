package dtrack.fixtures;

import fit.ColumnFixture;
import dtrack.messages.SuitRegistrationMessage;
import dtrack.Utilities;

public class MessageSentToManufacturing extends ColumnFixture {
  private SuitRegistrationMessage message;
  public void execute() throws Exception {
    message = (SuitRegistrationMessage)Utilities.getLastMessageToManufacturing();
  }

  public String messageId() {
    return message.id;
  }

  public int messageArgument() {
    return message.argument;
  }

  public String messageSender() {
    return message.sender;
  }
}
