
import junit.framework.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.objectmentor.SocketService.SocketServer;
import com.objectmentor.SocketService.SocketService;

public class TestSMCRemoteClient extends TestCase {
    private SMCRemoteClient c;
    private static final int SMCPORT = 9000;

    public TestSMCRemoteClient(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        c = new SMCRemoteClient();
    }

    public void testParseCommandLine() throws Exception {
        c.parseCommandLine(new String[]{"filename"});
        assertEquals("filename", c.filename());
    }

    public void testParseInvalidCommandLine() {
        boolean result = c.parseCommandLine(new String[0]);
        assertTrue("result should be false", !result);
    }

    public void testFileDoesNotExist() throws Exception {
        c.setFilename("thisFileDoesNotExist");
        boolean prepared = c.prepareFile();
        assertEquals(false, prepared);
    }

    public void testCountBytesInFile() throws Exception {
        File f = new File("testFile");
        FileOutputStream stream = new FileOutputStream(f);
        stream.write("some text".getBytes());
        stream.close();

        c.setFilename("testFile");
        boolean prepared = c.prepareFile();
        f.delete();
        assertTrue(prepared);
        assertEquals(9, c.getFileLength());
    }

    public void testConnectToSMCRemoteServer() throws Exception {
        SocketServer server = new SocketServer() {
            public void serve(Socket socket) {
                try {
                    socket.close();
                } catch (IOException e) {
                }
            }
        };
        SocketService smc = new SocketService(SMCPORT, server);
        boolean connection = c.connect();
        assertTrue(connection);
    }
}