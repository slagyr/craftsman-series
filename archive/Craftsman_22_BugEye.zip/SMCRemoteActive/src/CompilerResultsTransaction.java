
import java.io.Serializable;
import java.io.File;

public class CompilerResultsTransaction implements Serializable {
  private FileCarrier resultFile;

  public CompilerResultsTransaction(File subdirectory,
                                    String filename) throws Exception {
    resultFile = new FileCarrier(subdirectory, filename);
  }

  public void write() throws Exception {
    resultFile.write();
  }
}
