
import java.io.File;

public class SMCRemoteServer {
  private static final String SMC_CLASSPATH = "C:/SMC/smc.jar";
  private static final String SMC_CLASSNAME = "smc.Smc";
  private static int workingDirectoryIndex = 0;

  public static String buildCommandLine(String file) {
    return "java -cp " +
      SMC_CLASSPATH + " " +
      SMC_CLASSNAME +
      " -f " + file;
  }

  public static boolean executeCommand(String command) {
    Runtime rt = Runtime.getRuntime();
    try {
      Process p = rt.exec("sh -c \"" + command + "\"");
      p.waitFor();
      return p.exitValue() == 0;
    }
    catch (Exception e) {
      return false;
    }
  }

  public static File makeWorkingDirectory() {
    File workingDirectory = new File(makeUniqueWorkingDirectoryName());
    workingDirectory.mkdir();
    return workingDirectory;
  }

  private static String makeUniqueWorkingDirectoryName() {
    return "workingDirectory" +
      System.currentTimeMillis() + "_" +
      workingDirectoryIndex++;
  }

  public static void deleteWorkingDirectory(File workingDirectory) {
    File[] files = workingDirectory.listFiles();
    for (int i = 0; i < files.length; i++) {
      if (files[i].isDirectory())
        deleteWorkingDirectory(files[i]);
      files[i].delete();
    }
    workingDirectory.delete();
  }

  public static CompilerResultsTransaction
  compile(CompileFileTransaction cft, String command) throws Exception
  {
    File workingDirectory = makeWorkingDirectory();
    String wd = workingDirectory.getName();
    cft.sourceFile.write(workingDirectory);
    executeCommand("cd " + wd + ";" + command);
    return new CompilerResultsTransaction(workingDirectory, "files");
  }

}
